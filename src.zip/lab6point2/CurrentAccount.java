package lab6point2;



public class CurrentAccount extends Account{
	double overDraftlimit;


	public double getOverDraftlimit() {
		return overDraftlimit;
	}


	public void setOverDraftlimit(double overDraftlimit) {
		this.overDraftlimit = overDraftlimit;
	}


	public void withdraw(double amount) 
	{
		boolean status;
		status =checkOverDraftlimit(amount);
		if(status==true)

		{
			accBalance=accBalance-amount;
			System.out.println("transaction successful,balance:"+accBalance);
			}



		}
		public boolean checkOverDraftlimit(double amount)
		{
			boolean status;

			if(amount>overDraftlimit)
			{
				status = false;
				System.out.println("there is no enough fund");
			}
			else if

			(accBalance-amount<overDraftlimit)
			{
				System.out.println("unsuccessfull transaction");
				status = false;

			}
			else
			{
				accBalance=accBalance-amount;
				System.out.println("transaction successfull"+accBalance);
				status = true;
			}
			return status;
		}



	}
