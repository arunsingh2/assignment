package lab6point2;



public class Account 
{long accNum;
double accBalance;
static int count=1;
Person accHolder;

public Account(){}

public long getAccNum() {
	return accNum;
}

public void setAccNum(long accNum) {
	this.accNum = accNum;
}

public double getAccBalance() {
	return accBalance;
}

public void setAccBalance(double accBalance) {
	this.accBalance = accBalance;
}

public Person getAccHolder() {
	return accHolder;
}

public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
public void deposit(double money)
{
	accBalance= accBalance+money;
}

public void withdraw(double money)
{
	if((accBalance=accBalance-money) < 500)
	{

      return;
	}
	accBalance =accBalance-money;
	

}







}

