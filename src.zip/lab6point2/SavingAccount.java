package lab6point2;



//import lab4point2.copy.Account;

public class SavingAccount extends Account
{
	final double minimumBalance =500;
	public double getMinimumBalance()
	{
		return minimumBalance;
	}
	
	public void withdraw(double amount) {
     if (amount>accBalance)
     {
    	 System.out.println("not sufficient funds");
     }
     else if(accBalance-amount<minimumBalance)
		{
			System.out.println("low Balance");
			
		}
		else
		{accBalance=accBalance-amount;
		System.out.println("Transaction successful"+accBalance);

		}}


}
