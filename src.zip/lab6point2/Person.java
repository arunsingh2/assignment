package lab6point2;



public class Person
{String name;
float age;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	
	return age;
}
public void setAge(float age) {
	
	
	if(age>15)
	{
		this.age = age;
	}
	else
	{
		throw new invalidageException("your age is not above 15 ");
	}
}


}

