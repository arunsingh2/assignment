package lab4;

public class Account extends Person
{
	long accNum;
	double balance;
	String accHolder;
	


	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public String getAccHolder() {
		return accHolder;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	public void setAccHolder(String string) {
		this.accHolder = string;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double balance,double deposit)
	{
		this.balance = balance+deposit;
	}
	public void withdraw(double balance,double withdrawn)
	{
		this.balance = balance - withdrawn;
	}

	public  double getBalance()
	{
		return balance;

	}
	
	public void checkInitialBalance(String name) {
		
	}
	}
	


