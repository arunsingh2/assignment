package lab4;
import java.util.Random;
import java.util.Scanner;

import sun.net.www.content.text.plain;
public class TestAccount extends Account{
       

	public static void main(String[] args) {
		 Account ac1= new Account();
		 Account ac2= new Account();
	       Person p1 = new Person();
	       Person p2= new Person();
	       Random rand = new Random(6);

		//Scanner sc = new Scanner(System.in);
//System.out.println("Please ! Enter your name");

 p1.setName("smith");
p1.setAge(22.0F);
//float ag= sc.nextFloat();
//ac1.accNum =rand.nextLong();
long b = Math.abs(rand.nextLong());
ac1.setAccNum(b);
ac1.setBalance(2000);

ac1.deposit(ac1.getBalance(),2000);
ac1.setAccHolder(p1.getName());
ac1.checkInitialBalance(p1.getName());
System.out.println("name is "+ac1.getAccHolder());
System.out.println(ac1.getAccHolder()+"age is :"+p1.getAge());
System.out.println(ac1.getAccHolder()+"'s account number is "+ac1.getAccNum());
System.out.println("account balance is "+ac1.getBalance());
//System.out.println(ac1.getAccHolder());
p2.setName("Kathy");
p2.setAge(22.0F);
long c = Math.abs(rand.nextLong());
ac2.setAccNum(c);
ac2.setBalance(3000);
ac2.setAccHolder(p2.getName());

ac2.withdraw(ac2.getBalance(),2000);
 ac2.checkInitialBalance(p2.getName());

System.out.println("*************************");
//System.out.println("name is "+ac.getPersonname(ag))
System.out.println(ac2.getAccHolder());
System.out.println(p2.getAge());
System.out.println(ac2.getAccNum());
System.out.println(ac2.getBalance());
System.out.println(ac2.getAccHolder());
	}

	@Override
	public String toString() {
		return "TestAccount [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + ", name=" + name + ", age="
				+ age + ", getAccNum()=" + getAccNum() + ", getAccHolder()="
				+ getAccHolder() + ", toString()=" + super.toString()
				+ ", getBalance()=" + getBalance() + ", getName()=" + getName()
				+ ", getAge()=" + getAge() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}

}
