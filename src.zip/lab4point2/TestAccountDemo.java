package lab4point2;

import java.util.Random;

public class TestAccountDemo {

	public static void main(String[] args) {
		Random rand = new Random();
		Account Smith = new Account();
		Person pSmith = new Person();
		pSmith.setName("Smith");
		pSmith.setAge(21);
		Smith.setAccBalance(2000);
		Smith.setAccHolder(pSmith);
		Smith.setAccNum(Math.abs(rand.nextLong()));	


		Account Kathy = new Account();
		Person pKathy = new Person();
		pKathy.setName("Kathy");
		pKathy.setAge(22);
		Kathy.setAccBalance(3000);
		Kathy.setAccNum(Math.abs(rand.nextLong()));
		Kathy.setAccHolder(pKathy);


		Smith.deposit(2000);
		System.out.println("smith balance is"+Smith.getAccBalance());
		Kathy.withdraw(2000);
		System.out.println("kathy balance :"+Kathy.getAccBalance());

		SavingAccount savingAcnt =new SavingAccount();
		savingAcnt.withdraw(500);


		CurrentAccount curentAcc =new CurrentAccount();
		curentAcc.setOverDraftlimit(5000);
		curentAcc.setAccBalance(5000);;
		curentAcc.withdraw(500);


	}

}
