package lab6;

public class Employee 
{ private String firstName;
private String lastName;
private Gender gender;

public String getfirstName()
{
	return firstName;
}
public String getlastName() 
{
	return lastName;

}
public Gender getGender(){
	return gender;
}
public void setfistName(String firstName)
{
	this.firstName = firstName;
}
public void setlastName(String lastName)
{
	this.lastName = lastName;
}
public void setGender(Gender gender)
{
	this.gender = gender;
}








}