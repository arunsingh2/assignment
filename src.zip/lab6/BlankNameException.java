package lab6;

import java.io.PrintStream;
import java.io.PrintWriter;

public class BlankNameException extends RuntimeException{

	public BlankNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BlankNameException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BlankNameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BlankNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BlankNameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}