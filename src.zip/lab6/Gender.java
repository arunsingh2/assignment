package lab6;

public enum Gender {
  Male,Female,M,F
}
