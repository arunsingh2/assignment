package lab6;
import java.util.Scanner;
public class TestEmployee {

        public static void main(String[] args) {
        	Employee empn1= new Employee();
		Scanner sc = new Scanner(System.in);
       System.out.println("enter the first name");
	   String firsNam =sc.next();
		System.out.println("enter the last name");
		String lstNam = sc.next();
		
		
		
		
		//main code for user defined exceptions
		
		
		if(firsNam.equals(".")&&lstNam.equals("."))
		{
			throw new BlankNameException("this is user blank name Exception");
	}
		else
			
		{empn1.setfistName(firsNam);
		
		empn1.setlastName(lstNam);
		
		System.out.println("Enter 1 for gender:Male"+" "+"Enter two for gender:female");
		int gen = sc.nextInt();
		
		switch(gen)
		{
		case 1:
			empn1.setGender(Gender.Male);
			break;
		case 2:
			empn1.setGender(Gender.Female);
			
			
		}
		
		
         System.out.println("employee first name is "+empn1.getfirstName());
       System.out.println ("employee last name is "+empn1.getlastName());
       System.out.println("employee gender name is "+empn1.getGender());
		}

} }

